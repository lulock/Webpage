Basic examples: no additional Javascript needed to make it work.
